import { Component, OnInit } from '@angular/core';
import { Router, NavigationExtras} from '@angular/router';

@Component({
  selector: 'bloqueCreadorPlantilla',
  templateUrl: './CreadorPlantilla.component.html',
  styleUrls: ['./CreadorPlantilla.component.css']
})
export class CreadorPlantillaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
