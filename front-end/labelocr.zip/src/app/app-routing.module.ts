import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ObtenerPlantillaComponent } from './ObtenerPlantilla/ObtenerPlantilla.component';
import { ListaDatosComponent } from './ListaDatos/ListaDatos.component';
import { CreadorPlantillaComponent } from './CreadorPlantilla/CreadorPlantilla.component';

//AQUI SE INDICAN LAS DIFERENTES RUTAS PARA MOVERNOS POR LA APLICACION
const routes: Routes = [
  { path: '', redirectTo: 'Proveedor', pathMatch: 'full' },
  { path: 'Proveedor', component: ObtenerPlantillaComponent },
  { path: 'ListaDatos', component: ListaDatosComponent},
  { path: 'CreadorPlantilla', component: CreadorPlantillaComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
