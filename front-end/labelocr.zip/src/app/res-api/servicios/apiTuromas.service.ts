import { Caballetes } from '../modelos/caballetes';
import { Materiales } from '../modelos/materiales';
import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";

@Injectable({
  providedIn: "root"
})
export class ApiTuromasService {

  private turoUrl = "http://192.168.0.231:8081/turomas-api/store/v1.3/";
  private materials = "materials";// http://80.38.172.196:8081/turomas-api/store/v1.3/materials
  private structure = "structure";

  constructor(private http: HttpClient) {}

  public getMateriales(): Observable<Materiales> {
    return this.http.get<Materiales>(this.turoUrl + this.materials);
  }

  public getCaballetes(): Observable<Caballetes> {
    return this.http.get<Caballetes>(this.turoUrl + this.structure);
  }

}
