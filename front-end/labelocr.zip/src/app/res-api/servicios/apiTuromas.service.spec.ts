import { TestBed } from '@angular/core/testing';

import { ApiTuromasService } from './apiTuromas.service';

describe('ApiService', () => {
  let service: ApiTuromasService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ApiTuromasService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
