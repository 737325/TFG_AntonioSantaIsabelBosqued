/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { ApiServidorService } from './apiServidor.service';

describe('Service: ApiServidor', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ApiServidorService]
    });
  });

  it('should ...', inject([ApiServidorService], (service: ApiServidorService) => {
    expect(service).toBeTruthy();
  }));
});
