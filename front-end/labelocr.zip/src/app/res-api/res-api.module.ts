import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { ObtenerListComponent } from './componentes/obtener-list/obtener-list.component';
import { VerPlantillasComponent } from './componentes/ver-plantillas/ver-plantillas.component'; // <----

@NgModule({
  declarations: [ ObtenerListComponent, VerPlantillasComponent],
  imports: [CommonModule],
  exports: [ObtenerListComponent, VerPlantillasComponent]
})
export class ResApiModule {}
