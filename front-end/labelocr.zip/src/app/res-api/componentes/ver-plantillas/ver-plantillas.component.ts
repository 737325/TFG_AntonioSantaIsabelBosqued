import { Component, OnInit } from '@angular/core';
import { PlantillaDatos } from 'src/app/clases/PlantillaDatos';
import { ApiServidorService } from '../../servicios/apiServidor.service';


@Component({
  selector: 'app-ver-plantillas',
  templateUrl: './ver-plantillas.component.html',
  styleUrls: ['./ver-plantillas.component.css']
})
export class VerPlantillasComponent implements OnInit {
  public plantillas: PlantillaDatos[] = [];

  constructor(private apiServidor: ApiServidorService) { }

  ngOnInit(): void {
    this.apiServidor.getListadoPlantillas().subscribe(plantillas => (this.plantillas = plantillas));
    console.log("---- ngOnInit.ApiServidorService FIN Plantillas cargadas: " + this.plantillas.length + " ----");
  }

  //Metodos para organizar las plantillas por proveedor. ANGULAR MATERIAL

}
