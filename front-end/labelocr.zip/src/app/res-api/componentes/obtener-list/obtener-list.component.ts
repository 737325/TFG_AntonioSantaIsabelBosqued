import { Materiales } from './../../modelos/materiales';
import { Component, OnInit } from '@angular/core';
import { ApiTuromasService } from "../../servicios/apiTuromas.service";
import { waitForAsync } from '@angular/core/testing';

@Component({
  selector: 'app-obtenerlist',
  templateUrl: './obtener-list.component.html',
  styleUrls: ['./obtener-list.component.css']
})
export class ObtenerListComponent implements OnInit {
  public materiales: Materiales = { name: "NOMBRE", description:"",materials:[{name:"a_a",description:"s_s"}] };

  constructor(private apiservice: ApiTuromasService) {
    //console.log("ObtenerListComponent::constructor()");
  }

  ngOnInit(): void {
    this.apiservice.getMateriales().subscribe(materiales => (this.materiales = materiales));
    console.log("ngOnInit. FIN");
    console.log(this.materiales.name);
  }

}
