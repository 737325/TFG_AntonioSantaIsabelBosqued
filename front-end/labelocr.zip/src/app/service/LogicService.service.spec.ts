/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { LogicServiceService } from './LogicService.service';

describe('Service: LogicService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [LogicServiceService]
    });
  });

  it('should ...', inject([LogicServiceService], (service: LogicServiceService) => {
    expect(service).toBeTruthy();
  }));
});
