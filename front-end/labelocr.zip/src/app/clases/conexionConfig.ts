export default{
  database :{
    host: 'localhost',
    port: 3306,
    user: "tur0",
    password: "tur0",
    database: "turomas_test",
  }
}
