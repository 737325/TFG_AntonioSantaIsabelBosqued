import { Rectangle } from "tesseract.js";

export class Campo {
  private campoNombre: string;

  private rectangulo: Rectangle;

  constructor(campoNombre: string, coordX: number, coordY: number, longX: number, longY: number){
    this.campoNombre = campoNombre;
    this.rectangulo = {left:coordX, top:coordY, width:longX, height:longY}
  }


  public getCampoNombre(): string {
    return this.campoNombre;
  }

  public setCampoNombre(campoNombre: string): void {
      this.campoNombre = campoNombre;
  }

  public getRectangulo(): Rectangle {
      return this.rectangulo;
  }

  public setRectangulo(rectangulo: Rectangle): void {
      this.rectangulo = rectangulo;
  }

}
